const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

const s3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const BUCKET_NAME = process.env.S3_BUCKET;
const TABLE_NAME = process.env.DYNAMO_DB_TABLE;

module.exports.uploadPDF = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { fileName, fileContent } = body;

    const fileKey = `${uuidv4()}.pdf`;

    // Upload the file to S3
    await s3
      .putObject({
        Bucket: BUCKET_NAME,
        Key: fileKey,
        Body: Buffer.from(fileContent, "base64"),
        ContentType: "application/pdf",
      })
      .promise();

    // Store file metadata in DynamoDB
    const metadata = {
      rl_file_upload_id: uuidv4(),
      fileName,
      fileKey,
      uploadDate: new Date().toISOString(),
    };

    await dynamoDB
      .put({
        TableName: TABLE_NAME,
        Item: metadata,
      })
      .promise();

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "File uploaded successfully!",
        metadata,
      }),
    };
  } catch (error) {
    console.error("Error uploading file", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "File upload failed" }),
    };
  }
};

module.exports.getFiles = async () => {
  try {
    const params = {
      TableName: process.env.DYNAMO_DB_TABLE,
    };

    const data = await dynamoDB.scan(params).promise();

    return {
      statusCode: 200,
      body: JSON.stringify(data.Items),
    };
  } catch (error) {
    console.error("Error fetching files", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Could not retrieve files" }),
    };
  }
};
